import React from 'react';
import 'antd/dist/antd.css';
import './App.css';
import Quiz from './components/Quiz/Quiz';
import { Layout } from 'antd';
const { Header, Content, Footer } = Layout;
function App() {
  return (
    <div className='App'>
      <Layout className='layout'>
        <Header>
          <div className='logo' />
        </Header>
        <Content style={{ padding: '0 50px' }}>
          <div className='site-layout-content'>
            <Quiz />
          </div>
        </Content>
        <Footer style={{ textAlign: 'center' }}>
          ©2020 Created by You Hao
        </Footer>
      </Layout>
      ,
    </div>
  );
}

export default App;
