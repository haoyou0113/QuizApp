import React from 'react';
import { Button } from 'antd';
export default function Result(props) {
  const { rightAnswer, score, setGameOver, setViewed } = props;
  const restart = () => {
    setViewed(true);
    setGameOver(false);
  };
  return (
    <div>
      <h1>{rightAnswer}</h1>
      <h2>{score.toFixed(2) * 100}</h2>
      <Button onClick={restart}>Restart</Button>
    </div>
  );
}
