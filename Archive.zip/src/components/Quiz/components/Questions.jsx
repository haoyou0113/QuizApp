import React from 'react';

export default function Questions(props) {
  const { question } = props;
  return <div>{question}</div>;
}
