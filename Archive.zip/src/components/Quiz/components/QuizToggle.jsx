import React, { useEffect, Fragment } from 'react';
import Axios from 'axios';
import { Button } from 'antd';
export default function QuizToggle(props) {
  const { setIndex, setQuestionData, setViewed, setLoading, loading } = props;
  const Data = async () => {
    try {
      setLoading(true);
      const incomingData = await Axios.get(
        `https://opentdb.com/api.php?amount=10&category=18&difficulty=easy&type=multiple`
      );
      setQuestionData(incomingData.data.results);
      setLoading(false);
    } catch (err) {
      console.error(err);
    }
  };
  //   useEffect(() => {
  //     setLoading(true);
  //     Axios.get(
  //       'https://opentdb.com/api.php?amount=10&category=18&difficulty=easy&type=multiple'
  //     )
  //       .then((res) => setQuestionData(res.data.results))
  //       .catch(() => {
  //         console.log('error');
  //       });
  //     setLoading(false);
  //   }, []);
  // const Data = () => {
  //   setLoading(true);
  //   console.log(loading);
  //   Axios.get(
  //     'https://opentdb.com/api.php?amount=10&category=18&difficulty=easy&type=multiple'
  //   )
  //     .then((res) => setQuestionData(res.data.results))
  //     .then(setLoading(false));
  //   console.log(loading);
  // };

  return (
    <Fragment>
      <Button
        onClick={(e) => {
          e.preventDefault();
          Data();
          setViewed(false);
          setIndex(0);
        }}
      >
        Start
      </Button>
    </Fragment>
  );
}
